import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import StratifiedKFold
from sklearn.base import clone
from src.models import get_models
from src.evaluation import calculate_metrics, plot_calibration, decision_curve_analysis
import matplotlib.pyplot as plt

def run_nested_cv(X, y, models, outer_splits=5, random_state=42):
    outer_cv = StratifiedKFold(n_splits=outer_splits, shuffle=True, random_state=random_state)

    results = {name: [] for name in models.keys()}
    all_probs = {name: np.zeros(len(y)) for name in models.keys()}

    for fold, (train_idx, test_idx) in enumerate(outer_cv.split(X, y), 1):
        print(f"Outer Fold {fold}/{outer_splits}")

        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        for name, model in models.items():
            clf = clone(model)
            clf.fit(X_train, y_train)

            y_prob = clf.predict_proba(X_test)[:, 1]
            all_probs[name][test_idx] = y_prob

            metrics = calculate_metrics(y_test, y_prob)
            results[name].append(metrics)

    summary = {}
    for name in models.keys():
        df = pd.DataFrame(results[name])
        summary[name] = df.mean().to_dict()

    return summary, all_probs

def main():
    Path("results/figures").mkdir(parents=True, exist_ok=True)
    Path("results/tables").mkdir(parents=True, exist_ok=True)

    df = pd.read_csv("data/healthcare_workers_ef.csv")
    X = df.drop(columns=["ef_decline"])
    y = df["ef_decline"]

    models = get_models()
    summary, all_probs = run_nested_cv(X, y, models)

    print("\n" + "="*60)
    print("NESTED CROSS-VALIDATION RESULTS")
    print("="*60)
    for name, metrics in summary.items():
        print(f"\n{name}")
        for k, v in metrics.items():
            print(f"  {k}: {v:.3f}")

    pd.DataFrame(summary).T.to_csv("results/tables/nested_cv_results.csv")

    best_model = max(summary, key=lambda x: summary[x]["AUC"])
    print(f"\nBest model: {best_model}")

    y_prob_best = all_probs[best_model]

    plot_calibration(
        y, y_prob_best,
        title=f"Calibration – {best_model}",
        save_path="results/figures/calibration_plot.png"
    )

    thresholds, nb_model, nb_all = decision_curve_analysis(y, y_prob_best)

    plt.figure(figsize=(8, 6))
    plt.plot(thresholds, nb_model, label=best_model, linewidth=2)
    plt.plot(thresholds, nb_all, label="Treat All", linestyle="--")
    plt.plot(thresholds, np.zeros_like(thresholds), label="Treat None", linestyle=":")
    plt.xlabel("Threshold probability")
    plt.ylabel("Net Benefit")
    plt.title("Decision Curve Analysis")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig("results/figures/decision_curve.png", dpi=300, bbox_inches="tight")
    plt.close()

    print("\nFigures saved in results/figures/")
    print("Tables saved in results/tables/")

if __name__ == "__main__":
    main()
