import numpy as np
import pandas as pd

def generate_data(n_samples=1200, random_state=42):
    np.random.seed(random_state)

    age = np.random.normal(35, 8, n_samples).clip(24, 58)
    gender = np.random.binomial(1, 0.58, n_samples)
    experience_years = (age - 24) * np.random.uniform(0.5, 1.1, n_samples)
    weekly_hours = np.random.normal(46, 10, n_samples).clip(32, 75)
    night_shifts_per_month = np.random.poisson(3.8, n_samples).clip(0, 14)
    perceived_stress = np.random.normal(5.9, 1.9, n_samples).clip(1, 10)
    sleep_quality = np.random.normal(6.1, 1.8, n_samples).clip(1, 10)
    recovery = np.random.normal(5.7, 1.9, n_samples).clip(1, 10)
    baseline_ef = np.random.normal(74, 12, n_samples).clip(40, 100)

    # Adjusted coefficients for better balance (~20-25% positive)
    logit = (
        -2.1
        + 0.038 * age
        + 0.028 * weekly_hours
        + 0.15 * night_shifts_per_month
        + 0.29 * perceived_stress
        - 0.22 * sleep_quality
        - 0.19 * recovery
        - 0.035 * baseline_ef
        + 0.12 * gender
    )

    prob = 1 / (1 + np.exp(-logit))
    ef_decline = np.random.binomial(1, prob)

    df = pd.DataFrame({
        "age": age.round(1),
        "gender": gender,
        "experience_years": experience_years.round(1),
        "weekly_hours": weekly_hours.round(1),
        "night_shifts_per_month": night_shifts_per_month,
        "perceived_stress": perceived_stress.round(1),
        "sleep_quality": sleep_quality.round(1),
        "recovery": recovery.round(1),
        "baseline_ef_score": baseline_ef.round(1),
        "ef_decline": ef_decline
    })
    return df

if __name__ == "__main__":
    df = generate_data()
    df.to_csv("data/healthcare_workers_ef.csv", index=False)
    print("Improved dataset created successfully!")
    print("\nClass balance:")
    print(df["ef_decline"].value_counts(normalize=True).round(3))
