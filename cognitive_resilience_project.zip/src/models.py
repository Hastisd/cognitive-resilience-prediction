from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.pipeline import Pipeline
from src.preprocessing import get_preprocessor

def get_models():
    preprocessor = get_preprocessor()

    models = {
        "Logistic Regression": Pipeline([
            ("pre", preprocessor),
            ("model", LogisticRegression(
                max_iter=1000,
                class_weight="balanced",
                random_state=42
            ))
        ]),
        "Random Forest": Pipeline([
            ("pre", preprocessor),
            ("model", RandomForestClassifier(
                n_estimators=300,
                class_weight="balanced",
                random_state=42,
                n_jobs=-1
            ))
        ]),
        "XGBoost": Pipeline([
            ("pre", preprocessor),
            ("model", XGBClassifier(
                n_estimators=300,
                learning_rate=0.05,
                max_depth=4,
                subsample=0.8,
                colsample_bytree=0.8,
                scale_pos_weight=1.5,
                random_state=42,
                eval_metric="logloss",
                use_label_encoder=False
            ))
        ])
    }
    return models
